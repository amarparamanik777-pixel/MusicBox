@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)

package com.musicbox.app.ui.components

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.musicbox.app.data.Bucket
import com.musicbox.app.ui.Dlg
import com.musicbox.app.ui.MainViewModel
import com.musicbox.app.ui.theme.Brand

@Composable
fun GlobalDialogs(vm: MainViewModel) {
    when (val d = vm.dialog) {
        is Dlg.EditSong -> EditSongDialog(vm, d.id) { vm.dialog = null }
        is Dlg.AddToFolder -> AddToFolderDialog(vm, d.ids) { vm.dialog = null }
        is Dlg.NewFolder -> NewFolderDialog(vm, d.thenAdd) { vm.dialog = null }
        Dlg.Sleep -> SleepDialog(vm) { vm.dialog = null }
        null -> {}
    }
}

@Composable
fun TextPromptDialog(
    title: String,
    label: String,
    initial: String,
    confirmText: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Card,
        title = { Text(title) },
        text = {
            OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text(label) }, singleLine = true)
        },
        confirmButton = {
            TextButton(onClick = {
                onConfirm(text)
                onDismiss()
            }) { Text(confirmText) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun NewFolderDialog(vm: MainViewModel, thenAdd: List<Long>, onDismiss: () -> Unit) {
    TextPromptDialog("New folder", "Folder name", "", "Create", onDismiss) { name ->
        vm.repo.createFolder(name, thenAdd)
    }
}

@Composable
fun AddToFolderDialog(vm: MainViewModel, ids: List<Long>, onDismiss: () -> Unit) {
    val data by vm.repo.userData.collectAsState()
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Card,
        title = { Text("Add to folder") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (data.folders.isEmpty()) Text("You have no folders yet.", color = Brand.Dim)
                for (f in data.folders) {
                    TextButton(onClick = {
                        vm.repo.addToFolder(f.id, ids)
                        onDismiss()
                    }, modifier = Modifier.fillMaxWidth()) { Text("${f.name}  (${f.songIds.size})") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onDismiss()
                vm.dialog = Dlg.NewFolder(ids)
            }) { Text("New folder") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun SleepDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Card,
        title = { Text("Sleep timer") },
        text = {
            Column {
                for (m in listOf(15, 30, 45, 60, 90)) {
                    TextButton(onClick = {
                        vm.player.setSleepTimer(m)
                        onDismiss()
                    }, modifier = Modifier.fillMaxWidth()) { Text("$m minutes") }
                }
                TextButton(onClick = {
                    vm.player.setSleepTimer(0)
                    onDismiss()
                }, modifier = Modifier.fillMaxWidth()) { Text("Turn off") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
fun EditSongDialog(vm: MainViewModel, id: Long, onDismiss: () -> Unit) {
    val index by vm.repo.index.collectAsState()
    val data by vm.repo.userData.collectAsState()
    val song = index.byId[id] ?: return
    val startArtist = if (song.bucket == Bucket.UNIDENTIFIED) (song.hint ?: "") else song.artistLabel
    var title by remember(id) { mutableStateOf(song.title) }
    var artist by remember(id) { mutableStateOf(startArtist) }
    var moods by remember(id) { mutableStateOf(song.moods.toSet()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Card,
        title = { Text("Edit song") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(song.song.fileName, color = Brand.Dim, fontSize = 11.sp, maxLines = 2)
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true)
                OutlinedTextField(
                    value = artist,
                    onValueChange = { artist = it },
                    label = { Text("Artist (folder)") },
                    supportingText = { Text("Known artist = their folder. Unknown name = Others.") },
                    singleLine = true,
                )
                Text("Mood", color = Brand.Dim, fontSize = 12.sp)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (m in data.moods) {
                        FilterChip(
                            selected = m.id in moods,
                            onClick = { moods = if (m.id in moods) moods - m.id else moods + m.id },
                            label = { Text(m.emoji + " " + m.name) },
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.repo.editSong(
                    id,
                    if (title.trim() == song.title) null else title,
                    if (artist.trim() == startArtist.trim()) null else artist,
                    if (moods == song.moods.toSet()) null else moods.toList(),
                )
                onDismiss()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Color.White) } },
    )
}
